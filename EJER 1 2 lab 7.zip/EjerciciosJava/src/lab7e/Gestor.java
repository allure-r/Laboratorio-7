package lab7e;

import java.io.BufferedReader; // Permite leer el archivo de texto línea por línea
import java.io.BufferedWriter; // Permite escribir texto en el archivo
import java.io.IOException; // Permite controlar errores de lectura y escritura
import java.nio.file.Files; // Proporciona métodos para trabajar con archivos
import java.nio.file.Path; // Representa la ruta del archivo
import java.nio.file.Paths; // Permite crear la ruta del archivo
import java.nio.file.StandardOpenOption; // Define cómo se abre y modifica el archivo
import java.util.ArrayList; // Permite almacenar una lista de personajes
import java.util.Scanner; // Permite leer las opciones y datos del usuario

public class Gestor { // Administra las operaciones de los personajes

    private ArrayList<Personaje> personajes; // Almacena los personajes en memoria
    private Path archivo; // Guarda la ruta del archivo donde se almacenan los datos
    // Constructor: inicializa la lista y carga los personajes guardados
    public Gestor() {
        personajes = new ArrayList<>(); // Crear una lista vacía de personajes
        archivo = Paths.get("personajes.txt"); // Definir el archivo de almacenamiento
        cargar(); // Recuperar los personajes guardados anteriormente
    }
    // Lee el archivo y carga sus personajes en la lista
    private void cargar() {
        if (!Files.exists(archivo)) { // Comprobar si el archivo existe
            return; // Si no existe, el gestor comienza con la lista vacía
        }
        // Abrir el archivo y cerrarlo automáticamente al terminar la lectura
        try (BufferedReader lector = Files.newBufferedReader(archivo)) {
            String linea; // Almacena temporalmente cada línea leída
            while ((linea = lector.readLine()) != null) { // Leer hasta llegar al final del archivo
                String[] datos = linea.split(";"); // Separar nombre, vida, ataque, defensa y alcance
                if (datos.length == 5) { // Comprobar que la línea tenga los cinco campos necesarios
                    try {
                        // Crear un personaje convirtiendo los números de texto a enteros
                        Personaje p = new Personaje(
                                datos[0], // Nombre del personaje
                                Integer.parseInt(datos[1]), // Vida
                                Integer.parseInt(datos[2]), // Ataque
                                Integer.parseInt(datos[3]), // Defensa
                                Integer.parseInt(datos[4])  // Alcance
                        );
                        // Evitar cargar personajes con nombres repetidos
                        if (buscar(p.getNombre()) == null) {
                            personajes.add(p); // Incorporar el personaje a la lista
                        }
                    } catch (IllegalArgumentException e) { // Detectar números inválidos o propiedades incorrectas
                        System.out.println("Registro invalido: " + linea);
                    }
                }
            }

        } catch (IOException e) { // Capturar errores al abrir o leer el archivo
            System.out.println("Error al leer: " + e.getMessage());
        }
    }
    // Busca un personaje por su nombre y devuelve el objeto encontrado
    private Personaje buscar(String nombre) {
        for (Personaje p : personajes) { // Revisar cada personaje registrado
            if (p.getNombre().equalsIgnoreCase(nombre.trim())) { // Comparar nombres sin distinguir mayúsculas
                return p; // Devolver el personaje encontrado
            }
        }
        return null; // Devolver null si no existe ningún personaje con ese nombre
    }
    // Muestra los datos de todos los personajes registrados
    public void mostrar() {
        if (personajes.isEmpty()) { // Comprobar si la lista no contiene personajes
            System.out.println("No hay personajes registrados.");
            return; // Finalizar el método porque no hay datos que mostrar
        }
        System.out.println("\n--- LISTA DE PERSONAJES ---");
        for (Personaje p : personajes) { // Recorrer todos los personajes
            System.out.println(p); // Mostrar sus datos usando el método toString()
        }
    }
    // Añade un personaje nuevo si su nombre todavía no está registrado
    public void agregar(Personaje p) {
        if (buscar(p.getNombre()) != null) { // Comprobar si ya existe un personaje con ese nombre
            System.out.println("El personaje ya existe.");
            return; // Cancelar el registro para evitar duplicados
        }
        personajes.add(p); // Agregar el personaje a la lista
        guardar(); // Actualizar el archivo para conservar el nuevo registro
        System.out.println("Personaje agregado correctamente.");
    }
    // Modifica las cuatro características de un personaje existente
    public void modificar(String nombre, int vida, int ataque,
                          int defensa, int alcance) {
        Personaje p = buscar(nombre); // Buscar al personaje por su nombre
        if (p == null) { // Comprobar si el personaje no fue encontrado
            System.out.println("Personaje no encontrado.");
            return; // Finalizar sin modificar ningún dato
        }
        // Actualizar las propiedades; los métodos set validan los valores
        p.setVida(vida); // Cambiar los puntos de vida
        p.setAtaque(ataque); // Cambiar el nivel de ataque
        p.setDefensa(defensa); // Cambiar el nivel de defensa
        p.setAlcance(alcance); // Cambiar la distancia de alcance
        guardar(); // Guardar los valores modificados en el archivo
        System.out.println("Personaje modificado correctamente.");
    }
    // Elimina un personaje existente utilizando su nombre
    public void eliminar(String nombre) {
        Personaje p = buscar(nombre); // Buscar el personaje que se desea eliminar
        if (p == null) { // Comprobar si el nombre no corresponde a ningún personaje
            System.out.println("Personaje no encontrado.");
            return; // Cancelar la eliminación
        }
        personajes.remove(p); // Eliminar el personaje de la lista
        guardar(); // Actualizar el archivo para que el personaje eliminado no reaparezca
        System.out.println("Personaje eliminado correctamente.");
    }
    // Guarda la lista completa de personajes en el archivo de texto
    private void guardar() {
        // Crear el archivo si no existe y reemplazar su contenido anterior
        try (BufferedWriter escritor = Files.newBufferedWriter(
                archivo,
                StandardOpenOption.CREATE, // Crear el archivo si todavía no existe
                StandardOpenOption.TRUNCATE_EXISTING, // Borrar el contenido anterior antes de guardar
                StandardOpenOption.WRITE)) { // Abrir el archivo para escritura
            for (Personaje p : personajes) { // Recorrer todos los personajes registrados
                // Guardar los cinco campos separados por punto y coma
                escritor.write(p.getNombre() + ";"
                        + p.getVida() + ";"
                        + p.getAtaque() + ";"
                        + p.getDefensa() + ";"
                        + p.getAlcance());
                escritor.newLine(); // Escribir un salto de línea para el siguiente personaje
            }
        } catch (IOException e) { // Capturar errores al guardar el archivo
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }
    // Método principal: muestra el menú y permite utilizar el gestor
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // Leer los datos introducidos por el usuario
        Gestor gestor = new Gestor(); // Crear el gestor y cargar los datos guardados
        int opcion; // Almacenar la opción elegida en el menú

        do { // Repetir el menú hasta que el usuario decida salir
            System.out.println("\n===== GESTOR DE PERSONAJES =====");
            System.out.println("1. Mostrar personajes");
            System.out.println("2. Añadir personaje");
            System.out.println("3. Modificar personaje");
            System.out.println("4. Eliminar personaje");
            System.out.println("5. Salir");
            System.out.print("Elige una opcion: ");
            try {
                opcion = Integer.parseInt(sc.nextLine()); // Leer y convertir la opción a entero
                switch (opcion) { // Ejecutar la operación correspondiente a la opción
                    case 1:
                        gestor.mostrar(); // Mostrar todos los personajes registrados
                        break; // Terminar este caso
                    case 2:
                        try {
                            System.out.print("Nombre: ");
                            String nombre = sc.nextLine(); // Leer el nombre del nuevo personaje
                            System.out.print("Vida: ");
                            int vida = Integer.parseInt(sc.nextLine()); // Leer la vida como entero
                            System.out.print("Ataque: ");
                            int ataque = Integer.parseInt(sc.nextLine()); // Leer el ataque como entero
                            System.out.print("Defensa: ");
                            int defensa = Integer.parseInt(sc.nextLine()); // Leer la defensa como entero
                            System.out.print("Alcance: ");
                            int alcance = Integer.parseInt(sc.nextLine()); // Leer el alcance como entero
                            // Crear el objeto y solicitar al gestor que lo registre
                            Personaje p = new Personaje(nombre, vida, ataque, defensa, alcance);
                            gestor.agregar(p); // Agregarlo y guardar los cambios
                        } catch (IllegalArgumentException e) { // Detectar datos numéricos o atributos inválidos
                            System.out.println("Datos invalidos: " + e.getMessage());
                        }
                        break; // Terminar este caso
                    case 3:
                        try {
                            System.out.print("Nombre del personaje a modificar: ");
                            String nombre = sc.nextLine(); // Leer el nombre del personaje existente
                            System.out.print("Nueva vida: ");
                            int vida = Integer.parseInt(sc.nextLine()); // Leer la nueva vida
                            System.out.print("Nuevo ataque: ");
                            int ataque = Integer.parseInt(sc.nextLine()); // Leer el nuevo ataque
                            System.out.print("Nueva defensa: ");
                            int defensa = Integer.parseInt(sc.nextLine()); // Leer la nueva defensa
                            System.out.print("Nuevo alcance: ");
                            int alcance = Integer.parseInt(sc.nextLine()); // Leer el nuevo alcance
                            // Buscar el personaje y actualizar sus propiedades
                            gestor.modificar(nombre, vida, ataque, defensa, alcance);
                            
                        } catch (IllegalArgumentException e) { // Detectar valores inválidos
                            System.out.println("Datos invalidos: " + e.getMessage());
                        }
                        break; // Terminar este caso

                    case 4:
                        System.out.print("Nombre del personaje a eliminar: ");
                        String nombre = sc.nextLine(); // Leer el nombre del personaje que se eliminará
                        gestor.eliminar(nombre); // Eliminarlo y guardar la lista actualizada
                        break; // Terminar este caso

                    case 5:
                        System.out.println("Programa finalizado."); // Informar que el programa terminó
                        break; // Terminar este caso

                    default:
                        System.out.println("Opcion no valida."); // Avisar que la opción no está disponible
                }

            } catch (NumberFormatException e) { // Capturar opciones que no sean números enteros
                System.out.println("Debes ingresar un numero entero.");
                opcion = 0; // Mantener el menú activo para volver a intentarlo
            }

        } while (opcion != 5); // Continuar mientras no se seleccione la opción de salida

    }
}
