package lab7e; 

import java.io.BufferedReader; // Leer archivos
import java.io.BufferedWriter; // Escribir archivos
import java.io.IOException; // Manejar errores de entrada y salida
import java.nio.file.Files; // Operaciones con archivos
import java.nio.file.Path; // Representar rutas
import java.nio.file.Paths; // Crear rutas de archivos
import java.nio.file.StandardOpenOption; // Opciones de escritura
import java.util.ArrayList; // Crear listas dinámicas
import java.util.Comparator; // Ordenar personajes
import java.util.Random; // Generar números aleatorios
import java.util.Scanner; // Leer datos del teclado

public class Gestor1 { // Clase encargada de gestionar los personajes

    private ArrayList<Personaje1> personajes; // Lista de personajes
    private Path archivo; // Archivo donde se guardan los personajes
    private Random random; // Generador de números aleatorios

    public Gestor1() { // Constructor del gestor
        personajes = new ArrayList<>(); // Crear una lista vacía
        archivo = Paths.get("personajes.txt"); // Definir el archivo de almacenamiento
        random = new Random(); // Inicializar el generador aleatorio
        cargar(); // Cargar los personajes guardados
    }

    private Personaje1 buscar(String nombre) { // Buscar personaje por nombre
        for (Personaje1 p : personajes) { // Recorrer la lista
            if (p.getNombre().equalsIgnoreCase(nombre.trim())) { // Comparar nombres sin distinguir mayúsculas
                return p; // Devolver el personaje encontrado
            }
        }
        return null; // Retornar null si no existe
    }

    private void cargar() { // Cargar personajes desde el archivo
        if (!Files.exists(archivo)) { // Verificar si existe el archivo
            return; // Terminar si no existe
        }

        try (BufferedReader lector = Files.newBufferedReader(archivo)) { // Abrir archivo para leer
            String linea; // Variable para almacenar cada línea

            while ((linea = lector.readLine()) != null) { // Leer todas las líneas
                String[] d = linea.split(";"); // Separar los datos por punto y coma

                try {
                    if (d.length != 6) { // Verificar que existan seis campos
                        continue; // Saltar la línea si está incompleta
                    }

                    Personaje1 p = new Personaje1( // Crear un personaje
                            d[0], // Nombre
                            Integer.parseInt(d[1]), // Vida
                            Integer.parseInt(d[2]), // Ataque
                            Integer.parseInt(d[3]), // Defensa
                            Integer.parseInt(d[4])); // Alcance

                    p.restaurarNivel(Integer.parseInt(d[5])); // Recuperar el nivel guardado

                    if (buscar(p.getNombre()) == null) { // Comprobar si ya existe
                        personajes.add(p); // Añadir a la lista
                    }

                } catch (IllegalArgumentException e) { // Capturar datos inválidos
                    System.out.println("Registro invalido: " + linea); // Mostrar el registro incorrecto
                }
            }

        } catch (IOException e) { // Capturar errores de lectura
            System.out.println("Error al cargar: " + e.getMessage()); // Mostrar el error
        }
    }

    private void guardar() { // Guardar los personajes en el archivo
        try (BufferedWriter escritor = Files.newBufferedWriter(
                archivo,
                StandardOpenOption.CREATE, // Crear el archivo si no existe
                StandardOpenOption.TRUNCATE_EXISTING, // Reemplazar el contenido anterior
                StandardOpenOption.WRITE)) { // Habilitar escritura

            for (Personaje1 p : personajes) { // Recorrer los personajes
                escritor.write(p.getNombre() + ";" // Guardar nombre
                        + p.getVida() + ";" // Guardar vida
                        + p.getAtaque() + ";" // Guardar ataque
                        + p.getDefensa() + ";" // Guardar defensa
                        + p.getAlcance() + ";" // Guardar alcance
                        + p.getNivel()); // Guardar nivel

                escritor.newLine(); // Pasar a la siguiente línea
            }

        } catch (IOException e) { // Capturar errores de escritura
            System.out.println("Error al guardar: " + e.getMessage()); // Mostrar el error
        }
    }

    public void mostrar() { // Mostrar todos los personajes
        if (personajes.isEmpty()) { // Verificar si la lista está vacía
            System.out.println("No hay personajes registrados."); // Mostrar mensaje
            return; // Terminar el método
        }

        for (Personaje1 p : personajes) { // Recorrer la lista
            System.out.println(p); // Mostrar los datos del personaje
        }
    }

    public void agregar(Personaje1 p) { // Agregar un personaje
        if (buscar(p.getNombre()) != null) { // Comprobar si el nombre ya existe
            System.out.println("El personaje ya existe."); // Mostrar advertencia
            return; // Evitar agregar duplicados
        }

        personajes.add(p); // Añadir personaje a la lista
        guardar(); // Guardar los cambios
        System.out.println("Personaje agregado correctamente."); // Confirmar operación
    }

    public void ordenar(int opcion) { // Ordenar personajes por atributo
        Comparator<Personaje1> comparador; // Comparador para establecer el orden

        switch (opcion) { // Evaluar el atributo seleccionado
            case 1:
                comparador = Comparator.comparingInt(Personaje1::getVida); // Ordenar por vida
                break;
            case 2:
                comparador = Comparator.comparingInt(Personaje1::getAtaque); // Ordenar por ataque
                break;
            case 3:
                comparador = Comparator.comparingInt(Personaje1::getDefensa); // Ordenar por defensa
                break;
            case 4:
                comparador = Comparator.comparingInt(Personaje1::getAlcance); // Ordenar por alcance
                break;
            default:
                System.out.println("Atributo no valido."); // Avisar que la opción es incorrecta
                return; // Terminar el método
        }

        personajes.sort(comparador); // Ordenar de menor a mayor
        mostrar(); // Mostrar la lista ordenada
    }

    public void crearAleatorios(int cantidad) { // Crear personajes aleatorios
        if (cantidad <= 0) { // Verificar que la cantidad sea positiva
            System.out.println("La cantidad debe ser positiva."); // Mostrar advertencia
            return; // Terminar el método
        }

        int creados = 0; // Contador de personajes creados

        while (creados < cantidad) { // Repetir hasta crear la cantidad solicitada
            String nombre = "Personaje" + (random.nextInt(9000) + 1000); // Generar nombre aleatorio

            if (buscar(nombre) == null) { // Comprobar que el nombre no exista
                Personaje1 p = new Personaje1( // Crear personaje aleatorio
                        nombre, // Nombre generado
                        random.nextInt(10) + 1, // Vida entre 1 y 10
                        random.nextInt(10) + 1, // Ataque entre 1 y 10
                        random.nextInt(10) + 1, // Defensa entre 1 y 10
                        random.nextInt(10) + 1); // Alcance entre 1 y 10

                personajes.add(p); // Añadir personaje a la lista
                creados++; // Incrementar contador
            }
        }

        guardar(); // Guardar los personajes generados
        System.out.println("Personajes aleatorios creados: " + creados); // Mostrar resultado
    }

    public void actualizarAtributo(String nombre, int opcion, int valor) { // Modificar un atributo
        Personaje1 p = buscar(nombre); // Buscar el personaje

        if (p == null) { // Verificar si existe
            System.out.println("Personaje no encontrado."); // Mostrar advertencia
            return; // Terminar el método
        }

        try {
            switch (opcion) { // Elegir el atributo que se modificará
                case 1:
                    p.setVida(valor); // Actualizar vida
                    break;
                case 2:
                    p.setAtaque(valor); // Actualizar ataque
                    break;
                case 3:
                    p.setDefensa(valor); // Actualizar defensa
                    break;
                case 4:
                    p.setAlcance(valor); // Actualizar alcance
                    break;
                default:
                    System.out.println("Atributo no valido."); // Avisar de una opción incorrecta
                    return; // Terminar el método
            }

            guardar(); // Guardar el atributo actualizado
            System.out.println("Atributo actualizado correctamente."); // Confirmar operación

        } catch (IllegalArgumentException e) { // Capturar valores inválidos
            System.out.println("Error: " + e.getMessage()); // Mostrar el motivo del error
        }
    }

    public void estadisticas() { // Calcular estadísticas de los personajes
        if (personajes.isEmpty()) { // Verificar si hay personajes
            System.out.println("No hay personajes registrados."); // Mostrar mensaje
            return; // Terminar el método
        }

        int total = personajes.size(); // Obtener cantidad de personajes
        double vida = 0; // Acumular la vida
        double ataque = 0; // Acumular el ataque
        double defensa = 0; // Acumular la defensa
        double alcance = 0; // Acumular el alcance

        for (Personaje1 p : personajes) { // Recorrer todos los personajes
            vida += p.getVida(); // Sumar vida
            ataque += p.getAtaque(); // Sumar ataque
            defensa += p.getDefensa(); // Sumar defensa
            alcance += p.getAlcance(); // Sumar alcance
        }

        System.out.println("Total de personajes: " + total); // Mostrar cantidad total
        System.out.printf("Vida promedio: %.2f%n", vida / total); // Calcular promedio de vida
        System.out.printf("Ataque promedio: %.2f%n", ataque / total); // Calcular promedio de ataque
        System.out.printf("Defensa promedio: %.2f%n", defensa / total); // Calcular promedio de defensa
        System.out.printf("Alcance promedio: %.2f%n", alcance / total); // Calcular promedio de alcance
    }

    public void importar(String ruta) { // Importar personajes de otro archivo
        Path origen = Paths.get(ruta); // Obtener la ruta del archivo externo

        if (!Files.exists(origen)) { // Comprobar si el archivo existe
            System.out.println("El archivo no existe."); // Mostrar advertencia
            return; // Terminar el método
        }

        int agregados = 0; // Contador de personajes importados

        try (BufferedReader lector = Files.newBufferedReader(origen)) { // Abrir archivo externo
            String linea; // Almacenar cada línea

            while ((linea = lector.readLine()) != null) { // Leer el archivo
                String[] d = linea.split(";"); // Separar los campos

                if (d.length != 5) { // Comprobar que haya cinco campos
                    System.out.println("Linea ignorada: " + linea); // Mostrar línea incorrecta
                    continue; // Pasar a la siguiente línea
                }

                try {
                    Personaje1 p = new Personaje1( // Crear personaje importado
                            d[0], // Nombre
                            Integer.parseInt(d[1]), // Vida
                            Integer.parseInt(d[2]), // Ataque
                            Integer.parseInt(d[3]), // Defensa
                            Integer.parseInt(d[4])); // Alcance

                    if (buscar(p.getNombre()) == null) { // Evitar nombres duplicados
                        personajes.add(p); // Agregar a la lista
                        agregados++; // Incrementar contador
                    }

                } catch (IllegalArgumentException e) { // Capturar registros inválidos
                    System.out.println("Registro invalido: " + linea); // Mostrar registro incorrecto
                }
            }

            guardar(); // Guardar los personajes importados
            System.out.println("Personajes importados: " + agregados); // Mostrar cantidad importada

        } catch (IOException e) { // Capturar errores del archivo
            System.out.println("Error al importar: " + e.getMessage()); // Mostrar el error
        }
    }

    public void subirNivel(String nombre) { // Aumentar el nivel de un personaje
        Personaje1 p = buscar(nombre); // Buscar el personaje

        if (p == null) { // Comprobar si existe
            System.out.println("Personaje no encontrado."); // Mostrar advertencia
            return; // Terminar el método
        }

        p.subirNivel(); // Incrementar nivel y mejorar atributos
        guardar(); // Guardar los cambios
        System.out.println("El personaje ha subido de nivel."); // Confirmar operación
        System.out.println(p); // Mostrar datos actualizados
    }

    public void eliminar(String nombre) { // Eliminar un personaje
        Personaje1 p = buscar(nombre); // Buscar el personaje

        if (p == null) { // Comprobar si existe
            System.out.println("Personaje no encontrado."); // Mostrar advertencia
            return; // Terminar el método
        }

        personajes.remove(p); // Quitar personaje de la lista
        guardar(); // Actualizar el archivo
        System.out.println("Personaje eliminado correctamente."); // Confirmar eliminación
    }

    public static void main(String[] args) { // Método principal del programa
        Scanner sc = new Scanner(System.in); // Crear lector del teclado
        Gestor1 gestor = new Gestor1(); // Crear el gestor
        int opcion = 0; // Guardar la opción elegida

        do { // Repetir el menú hasta salir
            System.out.println("\n===== GESTOR DE PERSONAJES ====="); // Mostrar título
            System.out.println("1. Mostrar personajes"); // Opción para mostrar
            System.out.println("2. Añadir personaje"); // Opción para agregar
            System.out.println("3. Ordenar por atributo"); // Opción para ordenar
            System.out.println("4. Crear personajes aleatorios"); // Opción para generar
            System.out.println("5. Actualizar un atributo"); // Opción para modificar
            System.out.println("6. Mostrar estadisticas"); // Opción para estadísticas
            System.out.println("7. Importar desde archivo"); // Opción para importar
            System.out.println("8. Subir nivel"); // Opción para subir de nivel
            System.out.println("9. Eliminar personaje"); // Opción para eliminar
            System.out.println("10. Salir"); // Opción para terminar
            System.out.print("Elige una opcion: "); // Solicitar opción

            try {
                opcion = Integer.parseInt(sc.nextLine()); // Leer opción ingresada

                switch (opcion) { // Ejecutar la opción elegida
                    case 1:
                        gestor.mostrar(); // Mostrar personajes
                        break;

                    case 2:
                        try {
                            System.out.print("Nombre: "); // Solicitar nombre
                            String nombre = sc.nextLine(); // Leer nombre

                            System.out.print("Vida: "); // Solicitar vida
                            int vida = Integer.parseInt(sc.nextLine()); // Leer vida

                            System.out.print("Ataque: "); // Solicitar ataque
                            int ataque = Integer.parseInt(sc.nextLine()); // Leer ataque

                            System.out.print("Defensa: "); // Solicitar defensa
                            int defensa = Integer.parseInt(sc.nextLine()); // Leer defensa

                            System.out.print("Alcance: "); // Solicitar alcance
                            int alcance = Integer.parseInt(sc.nextLine()); // Leer alcance

                            gestor.agregar(new Personaje1( // Crear y agregar personaje
                                    nombre, vida, ataque, defensa, alcance));

                        } catch (IllegalArgumentException e) { // Capturar datos incorrectos
                            System.out.println("Datos invalidos: " + e.getMessage()); // Mostrar error
                        }
                        break;

                    case 3:
                        System.out.println("1. Vida  2. Ataque  3. Defensa  4. Alcance"); // Mostrar atributos
                        System.out.print("Ordenar por: "); // Solicitar atributo
                        gestor.ordenar(Integer.parseInt(sc.nextLine())); // Ordenar personajes
                        break;

                    case 4:
                        System.out.print("Cantidad de personajes aleatorios: "); // Solicitar cantidad
                        gestor.crearAleatorios(Integer.parseInt(sc.nextLine())); // Generar personajes
                        break;

                    case 5:
                        System.out.print("Nombre del personaje: "); // Solicitar nombre
                        String nombreAtributo = sc.nextLine(); // Leer nombre

                        System.out.println("1. Vida  2. Ataque  3. Defensa  4. Alcance"); // Mostrar atributos
                        System.out.print("Atributo a cambiar: "); // Solicitar atributo
                        int atributo = Integer.parseInt(sc.nextLine()); // Leer atributo elegido

                        System.out.print("Nuevo valor: "); // Solicitar nuevo valor
                        int valor = Integer.parseInt(sc.nextLine()); // Leer nuevo valor

                        gestor.actualizarAtributo(nombreAtributo, atributo, valor); // Actualizar atributo
                        break;

                    case 6:
                        gestor.estadisticas(); // Mostrar estadísticas
                        break;

                    case 7:
                        System.out.print("Ruta del archivo a importar: "); // Solicitar ruta
                        gestor.importar(sc.nextLine()); // Importar personajes
                        break;

                    case 8:
                        System.out.print("Nombre del personaje: "); // Solicitar nombre
                        gestor.subirNivel(sc.nextLine()); // Subir nivel
                        break;

                    case 9:
                        System.out.print("Nombre del personaje a eliminar: "); // Solicitar nombre
                        gestor.eliminar(sc.nextLine()); // Eliminar personaje
                        break;

                    case 10:
                        System.out.println("Programa finalizado."); // Mostrar mensaje de salida
                        break;

                    default:
                        System.out.println("Opcion no valida."); // Avisar opción incorrecta
                }

            } catch (NumberFormatException e) { // Capturar entradas que no sean números
                System.out.println("Debes ingresar un numero entero."); // Mostrar advertencia
            }

        } while (opcion != 10); // Repetir mientras no se elija salir

    }
}
