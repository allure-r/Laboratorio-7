package lab7e;

public class Personaje { // Representa a un personaje del videojuego
    private String nombre; // Guarda el nombre del personaje
    private int vida; // Guarda los puntos de vida del personaje
    private int ataque; // Guarda el nivel de ataque del personaje
    private int defensa; // Guarda el nivel de defensa del personaje
    private int alcance; // Guarda la distancia de alcance del personaje

    // Constructor: crea un personaje con sus cinco propiedades
    public Personaje(String nombre, int vida, int ataque, int defensa, int alcance) {
        setNombre(nombre); // Asigna el nombre y comprueba que sea válido
        setVida(vida); // Asigna la vida y comprueba que sea mayor que cero
        setAtaque(ataque); // Asigna el ataque y comprueba que sea válido
        setDefensa(defensa); // Asigna la defensa y comprueba que sea válida
        setAlcance(alcance); // Asigna el alcance y comprueba que sea válido
    }
    // Devuelve el nombre actual del personaje
    public String getNombre() {
        return nombre;
    }
    // Asigna un nombre al personaje después de validarlo
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) { // Evita nombres nulos o vacíos
            throw new IllegalArgumentException("El nombre no puede estar vacio");
        }
        this.nombre = nombre.trim(); // Guarda el nombre sin espacios al inicio ni al final
    }
    // Devuelve los puntos de vida
    public int getVida() {
        return vida;
    }
    // Permite cambiar la vida del personaje
    public void setVida(int vida) {
        if (vida <= 0) { // Comprueba que la vida sea un entero positivo
            throw new IllegalArgumentException("La vida debe ser mayor que cero");
        }
        this.vida = vida; // Actualiza el valor de vida
    }
    // Devuelve el nivel de ataque
    public int getAtaque() {
        return ataque;
    }
    // Permite cambiar el nivel de ataque
    public void setAtaque(int ataque) {
        if (ataque <= 0) { // Impide valores negativos o iguales a cero
            throw new IllegalArgumentException("El ataque debe ser mayor que cero");
        }
        this.ataque = ataque; // Actualiza el valor de ataque
    }
    // Devuelve el nivel de defensa
    public int getDefensa() {
        return defensa;
    }
    // Permite cambiar el nivel de defensa
    public void setDefensa(int defensa) {
        if (defensa <= 0) { // Comprueba que la defensa sea positiva
            throw new IllegalArgumentException("La defensa debe ser mayor que cero");
        }
        this.defensa = defensa; // Actualiza el valor de defensa
    }
    // Devuelve la distancia de alcance
    public int getAlcance() {
        return alcance;
    }
    // Permite cambiar el alcance del personaje
    public void setAlcance(int alcance) {
        if (alcance <= 0) { // Comprueba que el alcance sea positivo
            throw new IllegalArgumentException("El alcance debe ser mayor que cero");
        }
        this.alcance = alcance; // Actualiza el valor de alcance
    }
    // Devuelve todos los datos del personaje en una sola cadena de texto
    @Override
    public String toString() {
        return nombre + " | Vida: " + vida  + " | Ataque: " + ataque + " | Defensa: " + defensa  + " | Alcance: " + alcance;
    }
}
