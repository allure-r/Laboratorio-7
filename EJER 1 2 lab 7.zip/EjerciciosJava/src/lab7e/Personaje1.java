package lab7e;


public class Personaje1 { // Representa un personaje del videojuego

    private String nombre; // Nombre del personaje
    private int vida; // Puntos de vida
    private int ataque; // Poder de ataque
    private int defensa; // Capacidad de defensa
    private int alcance; // Distancia de alcance
    private int nivel; // Nivel actual del personaje

    public Personaje1(String nombre, int vida, int ataque, int defensa, int alcance) { // Constructor
        setNombre(nombre); // Validar y guardar el nombre
        setVida(vida); // Validar y guardar la vida
        setAtaque(ataque); // Validar y guardar el ataque
        setDefensa(defensa); // Validar y guardar la defensa
        setAlcance(alcance); // Validar y guardar el alcance
        nivel = 1; // Todos los personajes empiezan en nivel 1
    }

    public String getNombre() { return nombre; } // Obtener nombre
    public int getVida() { return vida; } // Obtener vida
    public int getAtaque() { return ataque; } // Obtener ataque
    public int getDefensa() { return defensa; } // Obtener defensa
    public int getAlcance() { return alcance; } // Obtener alcance
    public int getNivel() { return nivel; } // Obtener nivel

    public void setNombre(String nombre) { // Cambiar el nombre
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio");
        }
        this.nombre = nombre.trim(); // Guardar el nombre sin espacios externos
    }

    public void setVida(int vida) { // Actualizar vida
        if (vida <= 0) throw new IllegalArgumentException("La vida debe ser mayor que cero");
        this.vida = vida;
    }
    public void setAtaque(int ataque) { // Actualizar ataque
        if (ataque <= 0) throw new IllegalArgumentException("El ataque debe ser mayor que cero");
        this.ataque = ataque;
    }
    public void setDefensa(int defensa) { // Actualizar defensa
        if (defensa <= 0) throw new IllegalArgumentException("La defensa debe ser mayor que cero");
        this.defensa = defensa;
    }
    public void setAlcance(int alcance) { // Actualizar alcance
        if (alcance <= 0) throw new IllegalArgumentException("El alcance debe ser mayor que cero");
        this.alcance = alcance;
    }
    public void subirNivel() { // Aumentar el nivel del personaje
        nivel++; // Incrementar el nivel en uno
        vida++; // Mejorar la vida
        ataque++; // Mejorar el ataque
        defensa++; // Mejorar la defensa
        alcance++; // Mejorar el alcance
    }

    public void restaurarNivel(int nivelGuardado) { // Recuperar el nivel desde el archivo
        if (nivelGuardado < 1) {
            throw new IllegalArgumentException("El nivel debe ser mayor que cero");
        }
        nivel = nivelGuardado;
    }
    @Override
    public String toString() { // Mostrar todos los datos del personaje
        return nombre + " | Nivel: " + nivel
                + " | Vida: " + vida
                + " | Ataque: " + ataque
                + " | Defensa: " + defensa
                + " | Alcance: " + alcance;
    }
}
