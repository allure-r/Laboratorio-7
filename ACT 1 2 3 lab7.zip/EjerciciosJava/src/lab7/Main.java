package lab7;


import java.io.FileNotFoundException; // Importa la excepción que se produce si no se puede abrir o crear el archivo
import java.io.PrintWriter; // Importa la clase que permite escribir texto en un archivo
import java.util.Scanner; // Importa la clase que permite leer datos ingresados por teclado

public class Main { 

    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in); // Crea un Scanner para leer las líneas que escribe el usuario
        String cadena; // Declara una variable de tipo String para guardar cada línea de texto ingresada
        try (PrintWriter salida = new PrintWriter("datos.txt")) { // Abre o crea el archivo datos.txt; try-with-resources lo cierra automáticamente al terminar
            System.out.println("Introduce texto. Para acabar introduce la cadena FIN:"); // Muestra las instrucciones al usuario
            cadena = sc.nextLine(); // Lee la primera línea escrita por el usuario y la guarda en cadena
            while (!cadena.equalsIgnoreCase("FIN")) { // Repite el ciclo mientras la cadena ingresada sea diferente de FIN, sin distinguir mayúsculas y minúsculas
                salida.println(cadena); // Escribe la línea ingresada en el archivo y agrega un salto de línea
                cadena = sc.nextLine(); // Lee la siguiente línea para continuar con el ciclo
            } 
        } catch (FileNotFoundException e) { // Captura el error si no se puede abrir o crear el archivo
            System.out.println(e.getMessage()); // Muestra el mensaje que explica el motivo del error
        } 
    } 
} 
