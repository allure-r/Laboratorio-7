package lab7;

import java.io.IOException; // Maneja errores de entrada y salida
import java.nio.file.DirectoryStream; // Permite recorrer directorios
import java.nio.file.Files; // Permite obtener información de archivos
import java.nio.file.Path; // Representa una ruta
import java.nio.file.Paths; // Crea objetos Path
import java.util.Scanner; // Lee datos ingresados por el usuario

public class TestFile {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in); // Crear objeto Scanner
        System.out.println("Escriba el nombre del archivo o directorio:"); // Solicitar ruta
        Path ruta = Paths.get(sc.nextLine()); // Crear objeto Path con la ruta ingresada
        if (Files.exists(ruta)) { // Comprobar si la ruta existe
            System.out.printf("%n%s existe%n", ruta.getFileName()); // Mostrar nombre del archivo
            System.out.printf("%s un directorio%n",
                    Files.isDirectory(ruta) ? "Es" : "No es"); // Indicar si es directorio
            System.out.printf("%s una ruta absoluta%n",
                    ruta.isAbsolute() ? "Es" : "No es"); // Indicar si es ruta absoluta
            System.out.printf("Fecha de ultima modificacion: %s%n",
                    Files.getLastModifiedTime(ruta)); // Mostrar fecha de modificación
            System.out.printf("Tamanio: %d bytes%n",
                    Files.size(ruta)); // Mostrar tamaño en bytes
            System.out.printf("Ruta: %s%n", ruta); // Mostrar ruta ingresada
            System.out.printf("Ruta absoluta: %s%n",
                    ruta.toAbsolutePath()); // Mostrar ruta absoluta
            if (Files.isDirectory(ruta)) { // Comprobar si es un directorio
                System.out.println("\nContenido del directorio:"); // Mostrar título
                DirectoryStream<Path> flujoDirectorio =
                        Files.newDirectoryStream(ruta); // Obtener contenido del directorio
                for (Path p : flujoDirectorio) { // Recorrer los elementos del directorio
                    System.out.println(p); // Mostrar cada elemento
                }
                flujoDirectorio.close(); // Cerrar el flujo del directorio
            }
        } else { // Si la ruta no existe
            System.out.printf("%s no existe%n", ruta); // Mostrar mensaje de error
        }
        sc.close(); // Cerrar Scanner
    }
}
