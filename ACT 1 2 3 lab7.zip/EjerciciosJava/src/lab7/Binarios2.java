package lab7;

import java.io.FileNotFoundException; // Permite manejar errores al crear o abrir el archivo
import java.io.FileOutputStream; // Permite escribir datos en un archivo
import java.io.DataOutputStream; // Permite escribir datos primitivos en formato binario
import java.io.IOException; // Permite manejar errores de entrada y salida
import java.util.Scanner; // Permite leer datos ingresados por teclado

public class Binarios2 { // Declara la clase Binarios2

    public static void main(String[] args) { // Método principal del programa

        Scanner sc = new Scanner(System.in); // Crear un Scanner para leer datos por teclado
        FileOutputStream fos = null; // Declarar el flujo para escribir en el archivo
        DataOutputStream salida = null; // Declarar el flujo para escribir datos binarios
        double[][] matriz; // Declarar una matriz de números decimales
        int filas, columnas, i, j; // Declarar variables para las dimensiones y los índices

        do { // Repetir hasta que el número de filas sea válido
            System.out.print("Numero de filas: "); // Solicitar el número de filas
            filas = sc.nextInt(); // Leer el número de filas
        } while (filas <= 0); // No aceptar valores menores o iguales a cero

        do { // Repetir hasta que el número de columnas sea válido
            System.out.print("Numero de columnas: "); // Solicitar el número de columnas
            columnas = sc.nextInt(); // Leer el número de columnas
        } while (columnas <= 0); // No aceptar valores menores o iguales a cero

        matriz = new double[filas][columnas]; // Crear la matriz con las dimensiones ingresadas

        for (i = 0; i < filas; i++) { // Recorrer cada fila de la matriz
            for (j = 0; j < columnas; j++) { // Recorrer cada columna de la matriz
                System.out.print("matriz[" + i + "][" + j + "]: "); // Solicitar el valor de cada elemento
                matriz[i][j] = sc.nextDouble(); // Guardar el valor ingresado en la matriz
            }
        }

        try { // Iniciar el bloque para manejar posibles errores

            fos = new FileOutputStream("matriz.dat"); // Crear el archivo binario en el directorio de trabajo
            salida = new DataOutputStream(fos); // Crear el flujo para escribir datos primitivos

            salida.writeInt(filas); // Escribir el número de filas en el archivo
            salida.writeInt(columnas); // Escribir el número de columnas en el archivo

            for (i = 0; i < filas; i++) { // Recorrer cada fila para guardar sus elementos
                for (j = 0; j < columnas; j++) { // Recorrer cada columna para guardar sus elementos
                    salida.writeDouble(matriz[i][j]); // Escribir cada número double en formato binario
                }
            }

            System.out.println("Matriz guardada correctamente en matriz.dat"); // Informar que el archivo se creó correctamente

        } catch (FileNotFoundException e) { // Capturar errores al crear o abrir el archivo
            System.out.println(e.getMessage()); // Mostrar el mensaje del error

        } catch (IOException e) { // Capturar errores durante la escritura o el cierre
            System.out.println(e.getMessage()); // Mostrar el mensaje del error

        } finally { // Ejecutar este bloque al finalizar, incluso si ocurre un error

            try { // Intentar cerrar los flujos abiertos

                if (salida != null) { // Comprobar si el flujo de datos fue creado
                    salida.close(); // Cerrar el flujo de datos y vaciar los datos pendientes
                } else if (fos != null) { // Si salida no existe, comprobar si fos fue creado
                    fos.close(); // Cerrar el flujo de archivo
                }
            } catch (IOException e) { // Capturar errores al cerrar los flujos
                System.out.println(e.getMessage()); // Mostrar el mensaje del error
            }
        }
    }
}
